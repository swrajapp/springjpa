package com.dev.dao;

import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.dev.model.Book;

@Component
public class DaoClass {
	EntityManagerFactory emf= Persistence.createEntityManagerFactory("Librarydatabase");
	EntityManager em = emf.createEntityManager();
	EntityTransaction transaction = em.getTransaction();
	
	public void addBook(Book book)
	{
		transaction.begin();
		em.persist(book);
		transaction.commit();
	}
	
	public void deleteBook(String bookId) {
		Book book =  em.find(Book.class, bookId);
		transaction.begin();
		em.remove(book);
		transaction.commit();
	}
	
	public Book searchBook(String bookId) {
		Book book =  em.find(Book.class, bookId);
		return book;
	}
	
	public Book updateBook(String bookId, String bookName, String author, String publisher) {
		Book book =  em.find(Book.class, bookId);
		transaction.begin();
	    book.setAuthor(author);
		book.setBookName(bookName);
		book.setPublisher(publisher);
		em.persist(book);
		transaction.commit();
		return book;
	}
	
	 public List<Book> showAllBooks() {
	        Query<Book> query = em.createQuery("SELECT book FROM Book book", Book.class);
			List<Book> books = query.getResultList();
			return books;
	    }
	

}
