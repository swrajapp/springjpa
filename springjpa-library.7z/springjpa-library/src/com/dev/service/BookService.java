package com.dev.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.Dao;
import com.cg.model.Book;
import com.dev.dao.DaoClass;

@Service
public class BookService {

	@Autowired DaoClass daoClass;
	
	public void add(Book book){
		DaoClass.addBook(book);
	}

	public void deleteBook(String bookId) {
		daoClass.deleteBook(bookId);
	}
	
	public void updateBook(String bookId,String bookName,String author,String publisher)
	{
		daoClass.updateBook(bookId, bookName, author, publisher);
	}
	
	public Book searchBook(String bookId)
	{
	Book book=	daoClass.searchBook(bookId);
	return book;
	}
	
}
